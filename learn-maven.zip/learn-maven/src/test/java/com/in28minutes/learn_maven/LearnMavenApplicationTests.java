package com.in28minutes.learn_maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
